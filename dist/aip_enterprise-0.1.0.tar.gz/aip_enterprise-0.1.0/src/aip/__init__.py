"""AIP package root."""
