class ConfigurationError(RuntimeError):
    pass
