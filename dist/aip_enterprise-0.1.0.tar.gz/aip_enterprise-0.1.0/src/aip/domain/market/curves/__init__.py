"""Market curve models."""
