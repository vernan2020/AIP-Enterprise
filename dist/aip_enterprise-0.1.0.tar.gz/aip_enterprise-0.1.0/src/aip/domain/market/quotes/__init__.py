"""Market quote models."""
