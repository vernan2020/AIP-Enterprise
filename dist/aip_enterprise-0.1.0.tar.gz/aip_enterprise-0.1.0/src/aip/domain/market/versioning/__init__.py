"""Snapshot versioning support."""
