"""Market snapshot models."""
