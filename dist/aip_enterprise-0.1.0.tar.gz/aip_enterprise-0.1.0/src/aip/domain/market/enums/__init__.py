"""Market enums."""
