"""Market domain events."""
