"""Coopealianza-specific extensions."""
